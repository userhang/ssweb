/**
 * Created by gyj on 14-4-13.
 */
var obj={key:"1",value:2};
var newObj=obj;
newObj.value+=obj.key;
console.log(obj.value);
