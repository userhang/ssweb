/**
 * Created by gyj on 14-3-30.
 */
$(document).ready(function(){
	$('#showuipane').trigger('click');
//	$('#showfuncpane').trigger('click');
});